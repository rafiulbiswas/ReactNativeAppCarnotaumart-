import React, {Component} from 'react';
import { StyleSheet, Dimensions, ScrollView, Text, View  } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json

import Home from './app/classes/Home';
import Search from './app/classes/Search';
import Single from './app/classes/Single';
import Filterform from './app/classes/Filterform';

	
const Routes = createStackNavigator(
	{
		Home: Home,
		Search: Search,
		Single: Single,
		Filterform:Filterform,
	},{
		initialRouteName: 'Home',
	}
);



export default class App extends Component {
	render() {
		return <Routes />;
	}
}