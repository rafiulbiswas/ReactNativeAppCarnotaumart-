import {StyleSheet, Dimensions} from 'react-native';
    
export default StyleSheet.create({
	container: {
		flex: 1,
	},
	scrollContainer: {
		flex: 1,
		margin: 0,
		paddingBottom: 0,
		position: 'relative'	
	},
	gridView: {
		flexDirection: 'row',
		flexWrap: 'wrap',
		paddingLeft: 10
	},
	box: {
		height: 100,
		width: 120,
		paddingBottom: 15,
		paddingTop: 10,
		alignItems: 'center'
	},
	boxCenter: {
		height: 100,
		width: Dimensions.get('window').width,
		paddingBottom: 140,
		alignItems: 'center'
	},
	boxImage: {
		width: 50,
		height: 50
	},
	boxText: {
		fontWeight: '500',
		fontSize: 10,
		paddingLeft: 5
	},
	footer: {
		backgroundColor: '#012A46',
		marginTop: 20,
		paddingTop: 10,
		paddingBottom: 10
	},
	boxTextfooter: {
		color: 'white',
		textAlign: 'center'
	},
	footerImage: {
		alignItems: 'center',
		height: 25,
		width: 25
	}

});