import React, { Component } from 'react';
import { StyleSheet, Dimensions, ScrollView, Link, Button, Image, View, Text, TextInput, TouchableHighlight } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json
var FloatLabelTextInput = require('react-native-floating-label-text-input');
import { Dropdown } from 'react-native-material-dropdown';

class LogoTitle extends Component {
	render() {
		return (
			<TextInput style={{ height: 60, flex: 1 }}
				underlineColorAndroid="transparent"
				placeholder="Type Your Search Here"
				placeholderTextColor="#111111"
				autoCapitalize="none"
			/>
		);
	}
}


export default class Search extends Component {
	constructor(props) {
		super(props);

		this.state = {
			results: {
				status: 'OK',
				total: 0,
				posts: []
			},
			loadingImage: false

		};
		//Using ES6 we need to bind methods to access 'this'
		this.fetchData = this.fetchData.bind(this);
	}

	componentWillMount(){
		//const {getParam} = this.props.navigation;
		var ID=navigation.getParam('itemId',0);
	}
	  
	static navigationOptions = ({ navigate, navigation }) => {
		const {state} = navigation;
		return {
			headerLeft:
				<TouchableHighlight
					onPress={() =>
						navigation.navigate('Home')}>
					<Image style={{ marginLeft: 10, height: 15, width: 15 }}
						source={require('./../images/Arrow.png')} />
				</TouchableHighlight>,

			headerTitle: <LogoTitle />,
			headerRight:		
				<TouchableHighlight
					onPress={() =>navigation.navigate('Filterform',{ID: navigation.state.params.itemId})} >
					<Text>ID
						<Image style={{ marginRight: 20, height: 15, width: 15 }}
						source={require('./../images/Listing.png')}/></Text>
							
				</TouchableHighlight>
		};
	};

	

	apiCallBack() {
		const { navigation } = this.props;
		var ID=navigation.getParam('itemId',0);
		var location=navigation.getParam('location', 0);
		var brand=navigation.getParam('brand', 0);
		var model=navigation.getParam('model', 0);
		var minPrice=navigation.getParam('minPrice', 0);
        var maxPrice=navigation.getParam('maxPrice', 0);
		var fromYear = navigation.getParam('fromYear', 0);
	    var toYear=navigation.getParam('toYear', 0);
		var fuelType=navigation.getParam('fuelType', 0);
		var condition=navigation.getParam('condition', 0);
		var color=navigation.getParam('color', 0);
		var transmission=navigation.getParam('transmission', 0);

		return 'https://carnotautomart.com/beta/ApiSearch?categoryID=' + ID + '&location_id='+location+'&brand_id='+brand+'&model_id='
		+model+'&price_from='+minPrice+'&price_to='+maxPrice+'&year='+fromYear+'&year='+toYear+'&fuel_type='+fuelType+
		'&condition='+condition+'&color_id='+color+'&engine_size='+transmission+'';
		
	}

	componentDidMount() {
		this.fetchData();
		
	}

	fetchData() {
		var REQUEST_URL = this.apiCallBack();
		fetch(REQUEST_URL)
			.then((response) => response.json())
			.then((responseData) => {
				this.setState({
					results: responseData
				});
			})
			.done();
	}


	render() {

		total = this.state.results.total;
		contents = this.state.results.posts.map((post) => {
			//We need to return the corresponding mapping for each item too.
			return (
				<View style={styles.serchView}>
					<TouchableHighlight onPress={() => this.props.navigation.navigate
						('Single', { itemId: parseInt(post.ID) })}>
						<View>
							<Image style={styles.imageSize} source={this.state.loadingImage
								? require('./../images/car2.png') : { uri: post.Photos }} />
							<Text style={styles.postname}>{post.Name}</Text>
							<Text>
								<Text style={styles.id}>#ID {post.ID} </Text>
								<Text style={styles.car}>({post.Category}) </Text>
							</Text>
							<Text style={styles.boxTextfooter}>
								<Image style={styles.locationImage} source={require('./../images/location2.png')} />
								{post.Location}
							</Text>
							<Text style={styles.price}>{post.Price}</Text>
							<View style={styles.gridView}>
								<Text style={styles.box}>Verified: {post.IsFeatured}</Text>
								<Text style={styles.details}>More Details >></Text>
							</View>
						</View>
					</TouchableHighlight>
				</View>
			);
		});

		return (
			<ScrollView style={styles.scrollContainer}>
				<Text style={{ fontWeight: 'bold', paddingBottom: 10, paddingTop: 10 }}>Found: {total} ads in Nigeria</Text>

			
				<View>

					{contents}

				</View>

			</ScrollView>
		);
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	SectionStyle: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#fff',
		borderWidth: .5,
		borderColor: '#000',
		height: 40,
		borderRadius: 5,
		margin: 10
	},
	restulMatch: {
		fontWeight: 'bold',
		height: 30,

	},
	serchView: {
		width: Dimensions.get('window').width,
		borderBottomColor: 'green',
		borderBottomWidth: 2,
		marginBottom: 10,
		backgroundColor: '#FFFCDD',
		paddingTop: 0,
	},
	box: {
		color: '#007ACC',
		height: 40,
		width: Dimensions.get('window').width / 2.2,
		paddingTop: 10
	},
	gridView: {
		flexDirection: 'row',
		flexWrap: 'wrap',

	},
	searchBox: {

		height: 20,
		borderWidth: 1,
		borderColor: 'green',
		flex: 1

	},
	imageSize: {
		marginTop: 2,
		paddingTop: 0,
		height: 180,
		width: Dimensions.get('window').width / 1.11,

		borderColor: '#00050B'
	},
	scrollContainer: {
		flex: 1,
		paddingRight: 20,
		paddingLeft: 20,
		position: 'relative'
	},
	postname: {
		fontWeight: 'bold',
		height: 30,
		paddingTop: 10
	},

	id: {
		color: '#D29E18',
		paddingTop: -10
	},
	car: {
		fontWeight: 'bold'
	},
	location: {
		fontWeight: 'bold',
		height: 30
	},
	price: {
		fontWeight: 'bold',
		color: 'green',
		height: 20
	},
	locationImage: {
		width: 15,
		height: 22,
		paddingLeft: 10,
		marginRight: 10,
		paddingTop: 8
	},

	ImageStyle: {
		paddingLeft: 10,
		margin: 5,
		height: 10,
		width: 25,
		resizeMode: 'stretch',
		alignItems: 'center'
	},
	verifyed: {

		color: '#D29E18'
	},
	details: {
		color: '#F49363',
		height: 40,
		width: Dimensions.get('window').width / 2,
		paddingTop: 10,
		marginRight: -16


	},


});