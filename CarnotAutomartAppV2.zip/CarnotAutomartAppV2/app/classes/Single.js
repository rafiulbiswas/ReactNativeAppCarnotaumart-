import React, { Component } from 'react';
//import { StyleSheet, Dimensions, WebView, ScrollView, Link, Button, Image, View, Text, TextInput } from 'react-native';
import { StyleSheet, Dimensions, ScrollView, Link, Button, Image, View, Text, TextInput, TouchableHighlight } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json
import NavBar, { NavGroup, NavButton, NavButtonText, NavTitle } from 'react-native-nav'

class LogoTitle extends Component {
	render() {
	  return (
		<TextInput style={{height:60 ,flex:1}}
						underlineColorAndroid="transparent"
						placeholder="Type Your Search Here"
						placeholderTextColor="#111111"
						autoCapitalize="none"
		/>
	);
	}
  }


export default class Single extends Component {
	static navigationOptions = ({ navigation }) => {
		const params = navigation.state.params || {};

		return {
			headerLeft:
				<TouchableHighlight
					onPress={() => navigation.navigate('Search')}>
					<Image style={{ marginLeft:10, height: 15, width: 15 }} 
					source={require('./../images/Arrow.png')} />
			    </TouchableHighlight>,

			headerTitle: <LogoTitle />,
			headerRight: (
				<Image style={{ marginRight: 20, height: 15, width: 15 }} source={require('./../images/Listing.png')} />
			),
		};
	};
	
	constructor(props) {
		super(props);

		this.state = {
			results: {
				status: 'OK',
				total: 0,
				Details: [],
				Features: []
			}
		};
		//Using ES6 we need to bind methods to access 'this'
		this.fetchData = this.fetchData.bind(this);
	}
	apiCallBack() {
		const { navigation } = this.props;
		var ID = navigation.getParam('itemId', 0);
		return 'https://carnotautomart.com/beta/ApiSearch/'+ID;
		
	}

	componentDidMount() {
		this.fetchData();
	}

	fetchData() {
		var REQUEST_URL = this.apiCallBack();
		fetch(REQUEST_URL)
			.then((response) => response.json())
			.then((responseData) => {
				this.setState({
					results: responseData
				});
			})
			.done();
	}

	render() {
		
	
		Details = this.state.results.Details;
		Features = this.state.results.Features.map((post) => {
			//We need to return the corresponding mapping for each item too.
			return (
				<View style={styles.gridView}>
					 <Text>
					 <Image source={require('./../images/smalltick.png')} />
					 &nbsp;{post.Name}</Text>						 
				</View>
			);
		});

		return (

			
			<ScrollView style={styles.scrollContainer}>
				<View style={styles.searchView}>
				<Image style={styles.imageSize} source={{ uri: Details.Photos }} />
					<Text style={styles.postname}>{Details.title} </Text>
					<Text>
						<Text style={styles.id1}>#ID-{Details.ID}</Text>
						<Text style={styles.car}>({Details.Category})</Text>
					</Text>
					<Text style={styles.price1}>{Details.Price}</Text>
					<Text style={styles.boxTextfooter}>
						<Image style={styles.location1} source={require('./../images/location2.png')} />
						&nbsp;{Details.location}
					</Text>

				</View>

				<View style={styles.gridView}>
					<View style={styles.box}>
						<Image style={styles.sellerImage}
							source={require('./../images/seller.png')}
						/>
					</View>
					<View style={styles.box}>
						<Image style={styles.sellerImage}
							source={require('./../images/offer.png')}
						/>
					</View>
					<View style={styles.box}>
						<Image style={styles.sellerImage}
							source={require('./../images/phone2.png')}
						/>

					</View>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Brand</Text>
					<Text style={styles.dashtable}>{Details.brand_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Fuel Type</Text>
					<Text style={styles.dashtable}>{Details.fuel_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Miles Driven</Text>
					<Text style={styles.dashtable}>{Details.MilesDriven}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Color</Text>
					<Text style={styles.dashtable}>{Details.color_name}</Text>
				</View>
				<Text style={styles.price1}>
					<Image style={styles.iconImage}
						source={require('./../images/pen.png')}
					/>  Description</Text>
				<Text>{Details.description}</Text>

				<Text style={styles.registrationInfo}>
					<Image style={styles.iconImage}
						source={require('./../images/none.png')}
					/>  Registration Info</Text>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Registration Number</Text>
					<Text style={styles.dashtable}>{Details.registration_no}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Registration Date</Text>
					<Text style={styles.dashtable}>{Details.registration_date}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Manufacture Year</Text>
					<Text style={styles.dashtable}>{Details.manufacture_year}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Model Name</Text>
					<Text style={styles.dashtable}>{Details.model_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Engine Size</Text>
					<Text style={styles.dashtable}>{Details.enginesize_id}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Body Type</Text>
					<Text style={styles.dashtable}>{Details.body_type}</Text>
				</View>

				<Text style={styles.registrationInfo}>
					<Image style={styles.iconImage}
						source={require('./../images/info.png')}
					/>  Other Info</Text>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Gear Box Type</Text>
					<Text style={styles.dashtable}>{Details.gear_box_type}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Fuel Type</Text>
					<Text style={styles.dashtable}>{Details.fuel_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Color</Text>
					<Text style={styles.dashtable}>{Details.color_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Alloy Wheels</Text>
					<Text style={styles.dashtable}>{Details.alloywheels_name}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Seats</Text>
					<Text style={styles.dashtable}>{Details.seats}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Owners</Text>
					<Text style={styles.dashtable}>{Details.owner_id}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Service History</Text>
					<Text style={styles.dashtable}>{Details.service_history}</Text>
				</View>
				<View style={styles.gridView}>
					<Text style={styles.dashtable}>Conditions</Text>
					<Text style={styles.dashtable}>{Details.condition}</Text>
				</View>
				<Text style={styles.registrationInfo}>
					<Image style={styles.iconImage}
						source={require('./../images/tickmark.png')}
					/>   Features</Text>
				<View>{Features}</View>

			</ScrollView>

		);


	}

}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#FFFFFF',
	},
	imageSize: {
		marginTop:2,
		paddingTop:0,
		height: 180,
		width:Dimensions.get('window').width/1.11,
		borderColor: '#00050B'
	},
	scrollContainer: {
		flex: 1,
		margin: 0,
		paddingRight: 20,
		paddingLeft: 20,
		paddingBottom: 0,
		position: 'relative',
		backgroundColor: '#FFFFFF'
	},

	dashtable: {
		height: 30,
		width: Dimensions.get('window').width/2.6,
		paddingBottom: 10,
		borderBottomColor: '#FF973A',
	},

	input: {
		marginLeft: 0,
		marginTop: 10,
		height: 40,
		borderColor: '#111111',
		borderWidth: 1
	},
	postname: {
		fontWeight: 'bold',
		height: 40,
		paddingTop: 10
	},
	id1: {
		color: '#D29E18',
		height: 15
	},
	car1: {
		height: 15

	},
	price1: {
		fontWeight: 'bold',
		color: 'green',

	},
	borderView: {
		flexDirection: 'row',
		flexWrap: 'wrap',

		borderStyle: 'dashed',
		paddingLeft: 20
	},

	box: {
		paddingTop: 10,
		height: 50,
		width: Dimensions.get('window').width/3.4,
		paddingRight: 5

	},
	imageView: {
		marginTop: 10,
		height: 180,
		width:  Dimensions.get('window').width/1.11,
		borderWidth: 1,
		borderColor: '#00050B'
	},
	description:
		{
		    	
			
			width: Dimensions.get('window').width,
			
		},
	location1:
		{
			width: 25,
			height: 34
		},
	sellerImage:
		{
			height: 30,
			width: Dimensions.get('window').width/4
		},
	gridView: {
		flexDirection: 'row',
		flexWrap: 'wrap',

	},
	serchView: {
		width: Dimensions.get('window').width,
		borderBottomColor: 'green',
		borderBottomWidth: 2,
		marginBottom: 20,
		backgroundColor: '#FFFCDD'
	},
	iconImage: {
		height: 25,
		width: 25
	},
	registrationInfo: {
		color: 'green',
		height: 30,
		paddingTop: 10,
		marginBottom: 10
	}

});

