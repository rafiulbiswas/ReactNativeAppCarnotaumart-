import React, { Component } from 'react';
import { StyleSheet, Alert, document, Dimensions, Picker, ScrollView, Link, Button, Image, View, Text, TextInput, TouchableOpacity, TouchableHighlight } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json
var FloatLabelTextInput = require('react-native-floating-label-text-input');
import { Dropdown } from 'react-native-material-dropdown';
import { Select, Option } from 'react-native-select-lists';
import { Form } from 'react-native-form-idable';
import { Autobind } from 'es-decorators';

export default class Filterform extends Component {

  constructor(props) {
    super(props);

    //this.updateUser=this.updateUser.bind(this);
    this.state = {
      user:'',
         
    };
    this.updateUser = this.updateUser.bind(this);
    
  }

  updateUser = (user) => {
    this.setState({ user: user })
  }
 

	componentDidMount() {
    this.updateUser();
    
	}

  onSubmit = () => {
   
    const value = 'https://carnotautomart.com/beta/ApiSearch?categoryID='+this.state.user;
    Alert.alert(value);
  };



  render() {
    return (
      <ScrollView>
        <View style={styles.scrollContainer}>
          <Form
            onSubmit={this.onSubmit}
            toastErrors
            style={styles.form}
            onValidationError={errors => Alert.alert("error")}
          >
 
            <Picker selectedValue={this.state.user} onValueChange={this.updateUser}>         

              <Picker.Item label="Select Model" value="Model" />
              <Picker.Item label="100" value="1272" />
              <Picker.Item label="200" value="1273" />
              <Picker.Item label="25" value="1274" />
              <Picker.Item label="3500 Romeo" value="1275" />
              <Picker.Item label="400" value="1276" />
              <Picker.Item label="45" value="1277" />
              <Picker.Item label="600" value="1278" />
              <Picker.Item label="75 TOURER" value="1279" />
              <Picker.Item label="800" value="1280" />
              <Picker.Item label="CITY ROVER" value="1281" />
              <Picker.Item label="METRO" value="1282" />
              <Picker.Item label="MGF" value="1283" />
              <Picker.Item label="MINI TOURER" value="1284" />
              <Picker.Item label="STREETWISE" value="1285" />
            </Picker>
      
            <TouchableOpacity type="submit" style={styles.button}>
              <Text style={styles.buttonText}>Submit</Text>
            </TouchableOpacity>
            <Text style={styles.text}>{this.state.user}</Text>

            {/* <Button title="Get Selected Picker Value" onPress={this.GetSelectedPickerItem} /> */}
          </Form>
        </View>
      </ScrollView>

    );
  }


}



const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  scrollContainer: {
    flex: 1,
    backgroundColor: '#F7F7F7',
    width: '100%'

  },
  button: {
    alignSelf: 'stretch',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'blue',
    paddingHorizontal: 10,
    minHeight: 40,
  },
  buttonText: {
    fontSize: 20,
    color: 'white',
  },
  form: {
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },

});