import React, { Component } from 'react';
import { StyleSheet, Dimensions, ScrollView, Link, Button, Image, View, Text, TextInput, TouchableHighlight } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json
var FloatLabelTextInput = require('react-native-floating-label-text-input');
import { Dropdown } from 'react-native-material-dropdown';
import { Select, Option } from 'react-native-select-lists';
//import Select from 'react-select';

export default class Filterform extends Component {

  constructor(props) {
		super(props);

		this.state = {
			results: {
				Locations: [],
			}
		};
		//Using ES6 we need to bind methods to access 'this'
		this.fetchData = this.fetchData.bind(this);
	}


  apiCallBack() {
    const { navigation } = this.props;
    var ID = navigation.getParam('itemId', 0);
    return 'http://192.168.1.109/carnotautomart_new/rest-formdata.php';
  }
  componentDidMount() {
		this.fetchData();
	}

  fetchData() {
    var REQUEST_URL = this.apiCallBack();
    fetch(REQUEST_URL)
      .then((response) => response.json())
      .then((responseData) => {
        this.setState({
          results: responseData
        });
      })
      .done();
  }
  
  
    buildLocation (){
       LocationDropDown = this.state.results.Locations.map((Location) => {
        return (
          <Option value={Location.ID}>{Location.Name}{Location.ID}</Option>
          
        );
      });


      return (<View><Select> {LocationDropDown} </Select></View>);

    }
  
   render() {

    
  
     return (
        
      
       <View style={styles.scrollContainer}>
          { this.buildLocation() }
        <Select>
          <Option value={1}>List item 1</Option>
          <Option value={2}>List item 2</Option>
          <Option value={3}>List item 3</Option>
        </Select>
      
                
       </View>
    );
  }


}



const styles = StyleSheet.create({
	container: {
		flex: 1,
	},

	scrollContainer: {
		flex: 1,
		backgroundColor:'#F7F7F7',
		width:'100%'
	
	},
});