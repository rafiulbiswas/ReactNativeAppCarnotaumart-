import React, { Component } from 'react';
import { StyleSheet, Alert, document, Dimensions, Picker, ScrollView, Link, Button, Image, View, Text, TextInput, TouchableOpacity, TouchableHighlight } from 'react-native';
import { createStackNavigator } from 'react-navigation'; // Version can be specified in package.json
var FloatLabelTextInput = require('react-native-floating-label-text-input');
import { Dropdown } from 'react-native-material-dropdown';
import { Select, Option } from 'react-native-select-lists';
import { Form } from 'react-native-form-idable';
import { Autobind } from 'es-decorators';

export default class Filterform extends Component {

  constructor(props) {
    super(props);

    //this.updateUser=this.updateUser.bind(this);
    this.state = {
      PickerValueHolder: '',
      PickerValueHolder1: '',
      PickerValueHolder2: '',
      PickerValueHolder3: '',
      PickerValueHolder4: '',
      PickerValueHolder5: '',
      PickerValueHolder6: '',
      PickerValueHolder7: '',
      PickerValueHolder8: '',
      PickerValueHolder9: '',
      PickerValueHolder10: '',
    };
   
    
  }

componentDidMount()
{

}

  onSubmit = () => {
   
    const value = 
    this.state.PickerValueHolder+this.state.PickerValueHolder1+this.state.PickerValueHolder2+
    this.state.PickerValueHolder3+this.state.PickerValueHolder4+
    this.state.PickerValueHolder5+this.state.PickerValueHolder6+
    this.state.PickerValueHolder7+this.state.PickerValueHolder8+
    this.state.PickerValueHolder9+this.state.PickerValueHolder10;
    Alert.alert(value);
  };



  render() {
    return (
      <ScrollView>
        <View style={styles.scrollContainer}>
          <Form
            onSubmit={this.onSubmit}
            toastErrors
            style={styles.form}
            onValidationError={errors => Alert.alert("error")}
          >
  <Picker
          selectedValue={this.state.PickerValueHolder}
          onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder: itemValue })} >
          <Picker.Item label="Search Location" value="Location" />
          <Picker.Item label="Ogun" value="1" />
          <Picker.Item label="Lagos" value="2" />
          <Picker.Item label="Kaduna" value="3" />
          <Picker.Item label="Abuja" value="4" />
          <Picker.Item label="Cross-river" value="5" />
          <Picker.Item label="Cotonou" value='6' />
          <Picker.Item label="Imo" value="7" />
          <Picker.Item label="Osun" value="8" />
          <Picker.Item label="Kano" value="9" />
          <Picker.Item label="Taraba" value="10" />
          <Picker.Item label="Oyo" value="11" />
          <Picker.Item label="Ondo" value='12' />
          <Picker.Item label="Sokoto" value="13" />
          <Picker.Item label="Rivers State" value="14" />
          <Picker.Item label="Anambra" value="15" />
          <Picker.Item label="Ekiti" value="16" />
          <Picker.Item label="Abia" value='17' />
          <Picker.Item label="Adamawa" value="18" />
          <Picker.Item label="Akwa-Ibom" value="19" />
          <Picker.Item label="Bauchi" value="20" />
          <Picker.Item label="Bayelsa" value="21" />
          <Picker.Item label="Benue" value="22" />
          <Picker.Item label="Borno" value="23" />
          <Picker.Item label="Ebonyi" value="24" />
          <Picker.Item label="Enugu" value="25" />
          <Picker.Item label="Edo" value='26' />
          <Picker.Item label="Gombe" value="27" />
          <Picker.Item label="Jigawa" value="28" />
          <Picker.Item label="Katsina" value="29" />
          <Picker.Item label="Kebbi" value="30" />
          <Picker.Item label="Kogi" value="31" />
          <Picker.Item label="Kwara" value='32' />
          <Picker.Item label="Nasarawa" value="33" />
          <Picker.Item label="United States" value="34" />
          <Picker.Item label="Niger" value="35" />
          <Picker.Item label="Delta" value="36" />
          <Picker.Item label="Plateau" value='37' />
          <Picker.Item label="Yobe" value="38" />
          <Picker.Item label="Zamfara" value="39" />
          <Picker.Item label="United Kingdom" value="40" />
        </Picker>
 
        <Picker
          selectedValue={this.state.PickerValueHolder1}
          onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder1: itemValue })} >
          <Picker.Item label="Select Brand" value="Brand"/>
          <Picker.Item label="AC" value="49"/>
          <Picker.Item label="ARO" value="50" />
          <Picker.Item  label="Abarth" value="51"/>
          <Picker.Item  label="Aixam" value="52"/>
          <Picker.Item  label="Alfa Romeo" value="53"/>
          <Picker.Item  label="BMW" value="145"/>
          <Picker.Item  label="Bentley" value="146"/>
          <Picker.Item  label="ARIEL" value="168"/>
          <Picker.Item  label="ASTON MARTIN" value="169"/>
          <Picker.Item  label="ARM SIDDELEY" value="170"/>
          <Picker.Item  label="AUDI" value="171"/>
          <Picker.Item  label="AUSTIN" value="172"/>
          <Picker.Item  label="BEAUFORD" value="173"/>
          <Picker.Item  label="BRISTOL" value="174"/>
          <Picker.Item value="175" label="BUICK"/>
          <Picker.Item value="176" label="CADILLAC"/>
          <Picker.Item value="177" label="CARBODIES"/>
          <Picker.Item value="178" label="CATERHAM"/>
          <Picker.Item value="179" label="CHEVROLET"/>
          <Picker.Item value="180" label="CHRYSLER"/>
          <Picker.Item value="181" label="CITROEN"/>
          <Picker.Item value="182" label="COLEMAN MILNE"/>
          <Picker.Item value="183" label="CORVETTE"/>
          <Picker.Item value="184" label="DACIA"/>
          <Picker.Item value="185" label="DAEWOO"/>
          <Picker.Item value="186" label="DAIHATSU"/>
          <Picker.Item value="187" label="DAIMLER"/>
          <Picker.Item value="188" label="DATSUN"/>
          <Picker.Item value="189" label="DELOREAN"/>
          <Picker.Item value="190" label="DODGE"/>
          <Picker.Item value="191" label="DS"/>
          <Picker.Item value="192" label="FARBIO"/>
          <Picker.Item value="193" label="FERRARI"/>
          <Picker.Item value="195" label="FORD"/>
          <Picker.Item value="196" label="GINETTA"/>
          <Picker.Item value="197" label="GMC"/>
          <Picker.Item value="198" label="GREAT WALL"/>
          <Picker.Item value="199" label="GRINNALL"/>
          <Picker.Item value="200" label="HILLMAN"/>
          <Picker.Item value="201" label="HONDA"/>
          <Picker.Item value="202" label="HUMBER"/>
          <Picker.Item value="203" label="HUMMER"/>
          <Picker.Item value="204" label="HYUNDAI"/>
          <Picker.Item value="205" label="INFINITI"/>
          <Picker.Item value="206" label="ISUZU"/>
          <Picker.Item value="207" label="JAGUAR"/>
          <Picker.Item value="208" label="JEEP"/>
          <Picker.Item value="209" label="JENSEN"/>
          <Picker.Item value="210" label="JOWETT"/>
          <Picker.Item value="211" label="KIA"/>
          <Picker.Item value="212" label="KTM"/>
          <Picker.Item value="213" label="LAMBORGHINI"/>
          <Picker.Item value="214" label="LANCIA"/>
          <Picker.Item value="215" label="LAND ROVER"/>
          <Picker.Item value="216" label="LEXUS"/>
          <Picker.Item value="217" label="LINCOLN"/>
          <Picker.Item value="218" label="LOCUST"/>
          <Picker.Item value="219" label="LONDON TAXI'S INTERNATIONAL"/>
          <Picker.Item value="220" label="LOTUS"/>
          <Picker.Item value="221" label="MARCOS"/>
          <Picker.Item value="222" label="MARLIN"/>
          <Picker.Item value="223" label="MASERATI"/>
          <Picker.Item value="224" label="MAYBACH"/>
          <Picker.Item value="225" label="MAZDA"/>
          <Picker.Item value="226" label="MCLAREN"/>
          <Picker.Item value="227" label="MERCEDES-BENZ"/>
          <Picker.Item value="228" label="MEV"/>
          <Picker.Item value="229" label="MG"/>
          <Picker.Item value="230" label="MICROCAR"/>
          <Picker.Item value="231" label="MINI"/>
          <Picker.Item value="232" label="MITSUBISHI"/>
          <Picker.Item value="233" label="MITSUOKA"/>
          <Picker.Item value="234" label="MK"/>
          <Picker.Item value="235" label="MORGAN"/>
          <Picker.Item value="236" label="MORRIS"/>
          <Picker.Item value="237" label="NISSAN"/>
          <Picker.Item value="238" label="NOBLE"/>
          <Picker.Item value="239" label="OPEL"/>
          <Picker.Item value="240" label="PERODUA"/>
          <Picker.Item value="241" label="PEUGEOT"/>
          <Picker.Item value="242" label="PLYMOUTH"/>
          <Picker.Item value="243" label="POLARIS"/>
          <Picker.Item value="244" label="PONTIAC"/>
          <Picker.Item value="245" label="PORSCHE"/>
          <Picker.Item value="246" label="PROTON"/>
          <Picker.Item value="247" label="RCR"/>
          <Picker.Item value="248" label="RELIANT"/>
          <Picker.Item value="249" label="RENAULT"/>
          <Picker.Item value="250" label="REVA"/>
          <Picker.Item value="251" label="ROBIN HOOD"/>
          <Picker.Item value="252" label="ROLLS-ROYCE"/>
          <Picker.Item value="253" label="ROVER"/>
          <Picker.Item value="254" label="SAAB"/>
          <Picker.Item value="255" label="SANTANA"/>
          <Picker.Item value="256" label="SEAT"/>
          <Picker.Item value="257" label="SEBRING"/>
          <Picker.Item value="258" label="SINGER"/>
          <Picker.Item value="259" label="SKODA"/>
          <Picker.Item value="260" label="SMART"/>
          <Picker.Item value="261" label="SPYKER"/>
          <Picker.Item value="262" label="SSANGYONG"/>
          <Picker.Item value="263" label="STANDARD"/>
          <Picker.Item value="264" label="SUBARU"/>
          <Picker.Item value="265" label="SUZUKI"/>
          <Picker.Item value="266" label="TALBOT"/>
          <Picker.Item value="267" label="TATA"/>
          <Picker.Item value="268" label="TESLA"/>
          <Picker.Item value="269" label="TIGER"/>
          <Picker.Item value="270" label="TOYOTA"/>
          <Picker.Item value="271" label="TRIUMPH"/>
          <Picker.Item value="272" label="TVR"/>
          <Picker.Item value="273" label="ULTIMA"/>
          <Picker.Item value="274" label="VAUXHALL"/>
          <Picker.Item value="275" label="VOLKSWAGEN"/>
          <Picker.Item value="276" label="VOLVO"/>
          <Picker.Item value="277" label="WESTFIELD"/>
          <Picker.Item value="633" label="FIAT"/>
          <Picker.Item value="2149" label="Acura"/>
          <Picker.Item value="2195" label="Camaro"/>
          <Picker.Item value="2204" label="Man Diesel"/>
          <Picker.Item value="2206" label="TVS"/>
          <Picker.Item value="2214" label="All Brand"/>
          <Picker.Item value="2245" label="Bedford"/>
          <Picker.Item value="2246" label="IVECO"/>
          <Picker.Item value="2250" label="BAW"/>
        </Picker> 

        <Picker
          selectedValue={this.state.PickerValueHolder2}
          onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder2: itemValue })} >
          <Picker.Item label="Select Model" value="Model"/>
          
          <Picker.Item  label="100" value="1272" />
          <Picker.Item  label="200" value="1273"/>
          <Picker.Item  label="25" value="1274"/>
          <Picker.Item  label="3500 Romeo" value="1275"/>
          <Picker.Item  label="400" value="1276" />
          <Picker.Item  label="45" value="1277"/>
          <Picker.Item  label="600" value="1278"/>
          <Picker.Item  label="75 TOURER" value="1279"/>
          <Picker.Item  label="800" value="1280"/>
          <Picker.Item  label="CITY ROVER" value="1281" />
          <Picker.Item  label="METRO" value="1282"/>
          <Picker.Item  label="MGF" value="1283"/>
          <Picker.Item  label="MINI TOURER" value="1284"/>
          <Picker.Item  label="STREETWISE" value="1285"/>
        </Picker>
        <Picker
          selectedValue={this.state.PickerValueHolder3}
          onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder3: itemValue })} >
          <Picker.Item label="Min Price" value="pr"/>
          
          <Picker.Item value="100000"label="₦ 100,000"/>
          <Picker.Item value="500000"label="₦ 500,000" />
          <Picker.Item value="1000000"label="₦ 1,000,000 "/>
          <Picker.Item value="1500000"label="₦ 1,500,000 "/>
          <Picker.Item value="2000000"label="₦ 2,000,000 "/>
          <Picker.Item value="2500000"label="₦ 2,500,000 "/>
          <Picker.Item value="3000000"label="₦ 3,000,000 "/>
          <Picker.Item value="3500000"label="₦ 3,500,000 "/>
          <Picker.Item value="4000000"label="₦ 4,000,000 "/>
          <Picker.Item value="4500000"label="₦ 4,500,000 "/>
          <Picker.Item value="5000000"label="₦ 5,000,000 "/>
          <Picker.Item value="5500000"label="₦ 5,500,000 "/>
          <Picker.Item value="6000000"label="₦ 6,000,000 "/>
          <Picker.Item value="6500000"label="₦ 6,500,000 "/>
          <Picker.Item value="7000000"label="₦ 7,000,000 "/>
          <Picker.Item value="7500000"label="₦ 7,500,000 "/>
          <Picker.Item value="8000000"label="₦ 8,000,000 "/>
          <Picker.Item value="8500000"label="₦ 8,500,000 "/>
          <Picker.Item value="9000000"label="₦ 9,000,000 "/>
          <Picker.Item value="9500000"label="₦ 9,500,000 "/>
          <Picker.Item value="10000000"label="₦ 10,000,000 "/>
          <Picker.Item value="10500000"label="₦ 10,500,000 "/>
          <Picker.Item value="11000000"label="₦ 11,000,000 "/>
          <Picker.Item value="11500000"label="₦ 11,500,000 "/>
          <Picker.Item value="12000000"label="₦ 12,000,000 "/>
          <Picker.Item value="12500000"label="₦ 12,500,000 "/>
          <Picker.Item value="13000000"label="₦ 13,000,000 "/>
          <Picker.Item value="13500000"label="₦ 13,500,000 "/>
          <Picker.Item value="14000000"label="₦ 14,000,000 "/>
          <Picker.Item value="14500000"label="₦ 14,500,000 "/>
          <Picker.Item value="15000000"label="₦ 15,000,000 "/>
          <Picker.Item value="15500000"label="₦ 15,500,000 "/>
          <Picker.Item value="16000000"label="₦ 16,000,000 "/>
          <Picker.Item value="16500000"label="₦ 16,500,000 "/>
          <Picker.Item value="17000000"label="₦ 17,000,000 "/>
          <Picker.Item value="17500000"label="₦ 17,500,000 "/>
          <Picker.Item value="18000000"label="₦ 18,000,000 "/>
          <Picker.Item value="18500000"label="₦ 18,500,000 "/>
          <Picker.Item value="19000000"label="₦ 19,000,000 "/>
          <Picker.Item value="19500000"label="₦ 19,500,000 "/>
          <Picker.Item value="20000000"label="₦ 20,000,000 "/>
        </Picker>
       <Picker
          selectedValue={this.state.PickerValueHolder4}
          onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder4: itemValue })} >
          <Picker.Item label="Max Price" value="pr2"/>
          <Picker.Item value="100000"label="₦ 100,000"/>
          <Picker.Item value="500000"label="₦ 500,000" />
          <Picker.Item value="1000000"label="₦ 1,000,000 "/>
          <Picker.Item value="100000"label="₦ 2,000,000"/>
          <Picker.Item value="500000"label="₦ 2,500,000" />
          <Picker.Item value="1000000"label="₦ 3,000,000 "/>
          <Picker.Item value="100000"label="₦ 4,000,000"/>
          <Picker.Item value="500000"label="₦ 4,500,000" />
          <Picker.Item value="1000000"label="₦ 5,000,000 "/>
          <Picker.Item value="100000"label="₦ 5,500,000"/>
          <Picker.Item value="500000"label="₦ 6,000,000" />
          <Picker.Item value="1000000"label="₦ 6,500,000"/>
          <Picker.Item value="100000"label="₦ 7,000,000"/>
          <Picker.Item value="500000"label="₦ 7,500,000" />
          <Picker.Item value="1000000"label="₦ 8,500,000 "/>
          <Picker.Item value="100000"label="₦ 9,000,000"/>
          <Picker.Item value="500000"label="₦ 10,500,000" />
          <Picker.Item value="1000000"label="₦ 11,000,000 "/>
          <Picker.Item value="100000"label="₦ 12,500,000"/>
          <Picker.Item value="500000"label="₦ 13,000,000" />
          <Picker.Item value="1000000"label="₦ 14,500,000"/>
          <Picker.Item value="100000"label="₦ 15,000,000"/>
          <Picker.Item value="500000"label="₦ 16,500,000" />
          <Picker.Item value="1000000"label="₦ 17,500,000 "/>
          <Picker.Item value="100000"label="₦ 18,000,000"/>
          <Picker.Item value="500000"label="₦ 19,500,000" />
          <Picker.Item value="1000000"label="₦ 19,500,000 "/>
        </Picker>
        <Picker
                  selectedValue={this.state.PickerValueHolder5}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder5: itemValue })} >
                  <Picker.Item label="From Year" value="y1"/>
                  <Picker.Item value="100"label="2018"/>
                  <Picker.Item value="500"label="2017" />
                  <Picker.Item value="100"label="2016 "/>
                  <Picker.Item value="100"label="2015"/>
                  <Picker.Item value="500"label="2014" />
                  <Picker.Item value="100"label="2013"/>
                  <Picker.Item value="1000"label="2012"/>
                  <Picker.Item value="100"label="2011"/>
                  <Picker.Item value="500"label="2009" />
                  <Picker.Item value="100"label="2008 "/>
                  <Picker.Item value="100"label="2007"/>
                  <Picker.Item value="500"label="2006" />
                  <Picker.Item value="100"label="2005"/>
                  <Picker.Item value="1000"label="2004"/>
                  <Picker.Item value="100"label="2003"/>
                  <Picker.Item value="500"label="2002" />
                  <Picker.Item value="100"label="2001 "/>
                  <Picker.Item value="100"label="2000"/>
                  <Picker.Item value="500"label="1999" />
                  <Picker.Item value="100"label="1998"/>
                  <Picker.Item value="1000"label="1997"/>
                  <Picker.Item value="100"label="1996"/>
                  <Picker.Item value="500"label="1995" />
                  <Picker.Item value="100"label="1994 "/>
                  <Picker.Item value="100"label="1993"/>
                  <Picker.Item value="500"label="1992" />
                  <Picker.Item value="100"label="1991"/>
                  <Picker.Item value="1000"label="1990"/>
                  <Picker.Item value="100"label="1989"/>
                  <Picker.Item value="500"label="1988" />
                  <Picker.Item value="100"label="1987"/>
                  <Picker.Item value="100"label="1986"/>
                  <Picker.Item value="500"label="1985" />
                  <Picker.Item value="100"label="1984"/>
                  <Picker.Item value="1000"label="1983"/>
                  <Picker.Item value="500"label="1982" />
                  <Picker.Item value="100"label="1981"/>
                  <Picker.Item value="1000"label="1980"/>
        </Picker>
        <Picker
                  selectedValue={this.state.PickerValueHolder6}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder6: itemValue })} >
                  <Picker.Item label="To Year" value="y2"/>
                  <Picker.Item value="100"label="2018"/>
                  <Picker.Item value="500"label="2017" />
                  <Picker.Item value="100"label="2016 "/>
                  <Picker.Item value="100"label="2015"/>
                  <Picker.Item value="500"label="2014" />
                  <Picker.Item value="100"label="2013"/>
                  <Picker.Item value="1000"label="2012"/>
                  <Picker.Item value="100"label="2011"/>
                  <Picker.Item value="500"label="2009" />
                  <Picker.Item value="100"label="2008 "/>
                  <Picker.Item value="100"label="2007"/>
                  <Picker.Item value="500"label="2006" />
                  <Picker.Item value="100"label="2005"/>
                  <Picker.Item value="1000"label="2004"/>
                  <Picker.Item value="100"label="2003"/>
                  <Picker.Item value="500"label="2002" />
                  <Picker.Item value="100"label="2001 "/>
                  <Picker.Item value="100"label="2000"/>
                  <Picker.Item value="500"label="1999" />
                  <Picker.Item value="100"label="1998"/>
                  <Picker.Item value="1000"label="1997"/>
                  <Picker.Item value="100"label="1996"/>
                  <Picker.Item value="500"label="1995" />
                  <Picker.Item value="100"label="1994 "/>
                  <Picker.Item value="100"label="1993"/>
                  <Picker.Item value="500"label="1992" />
                  <Picker.Item value="100"label="1991"/>
                  <Picker.Item value="1000"label="1990"/>
                  <Picker.Item value="100"label="1989"/>
                  <Picker.Item value="500"label="1988" />
                  <Picker.Item value="100"label="1987"/>
                  <Picker.Item value="100"label="1986"/>
                  <Picker.Item value="500"label="1985" />
                  <Picker.Item value="100"label="1984"/>
                  <Picker.Item value="1000"label="1983"/>
                  <Picker.Item value="500"label="1982" />
                  <Picker.Item value="100"label="1981"/>
                  <Picker.Item value="1000"label="1980"/>
        </Picker>
        <Picker
                  selectedValue={this.state.PickerValueHolder7}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder7: itemValue })} >
                  <Picker.Item label="Fuel Type" value="fy"/>
                  <Picker.Item value="7"label="Unlisted" />
                  <Picker.Item value="6"label="Petrol"/>
                  <Picker.Item value="5"label="LPG" />
                  <Picker.Item value="4"label="Hybrid"/>
                  <Picker.Item value="3"label="Electric" />
                  <Picker.Item value="2"label="Diesel"/>
                  <Picker.Item value="1"label="Bi Fuel" />
        </Picker>
        <Picker
                  selectedValue={this.state.PickerValueHolder8}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder8: itemValue })} >
                  <Picker.Item label="Condition" value="cd"/>
                  <Picker.Item value="7"label="New" />
                  <Picker.Item value="6"label="Nigerian Used"/>
                  <Picker.Item value="5"label="Foreign Used" />

        </Picker>

        <Picker
                  selectedValue={this.state.PickerValueHolder9}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder9: itemValue })} >
                  <Picker.Item label="Color" value="cl"/>
                  <Picker.Item value="1"label="Beige" />
                  <Picker.Item value="2"label="Black"/>
                  <Picker.Item value="3"label="Blue" />
                  <Picker.Item value="4"label="Bronze" />
                  <Picker.Item value="5"label="Brown"/>
                  <Picker.Item value="6"label="Burgundy" />
                  <Picker.Item value="7"label="Gold" />
                  <Picker.Item value="8"label="Green" />
                  <Picker.Item value="9"label="Indigo"/>
                  <Picker.Item value="10"label="Magenta" />
                  <Picker.Item value="11"label="Maroon" />
                  <Picker.Item value="12"label="Multicolour"/>
                  <Picker.Item value="13"label="Navy" />
                  <Picker.Item value="14"label="Orange" />
                  <Picker.Item value="15"label="Pink"/>
                  <Picker.Item value="16"label="Purple" />
                  <Picker.Item value="17"label="Foreign Used" />
                  <Picker.Item value="18"label="Red" />
                  <Picker.Item value="19"label="Silver"/>
                  <Picker.Item value="21"label="Turquoise" />
                  <Picker.Item value="22"label="Unlisted"/>
                  <Picker.Item value="23"label="White" />
                  <Picker.Item value="24"label="Yellow" />
                  <Picker.Item value="25"label="Wine"/>
                  <Picker.Item value="26"label="Navy Blue" />
                  <Picker.Item value="27"label="Sky Blue" />
                  <Picker.Item value="28"label="Ash" />
        </Picker>
        <Picker
                  selectedValue={this.state.PickerValueHolder10}
                  onValueChange={(itemValue, itemIndex) => this.setState({ PickerValueHolder10: itemValue })} >
                  <Picker.Item label="Transmission" value="tr"/>
                  <Picker.Item value="1"label="Automatic" />
                  <Picker.Item value="2"label="Semi Automatic"/>
                  <Picker.Item value="3"label="Manual" />
        </Picker>

            <TouchableOpacity type="submit" style={styles.button}>
              <Text style={styles.buttonText}>Submit</Text>
            </TouchableOpacity>
            <Text style={styles.text}>{this.state.user}</Text>

            {/* <Button title="Get Selected Picker Value" onPress={this.GetSelectedPickerItem} /> */}
          </Form>
        </View>
      </ScrollView>

    );
  }


}



const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  scrollContainer: {
    flex: 1,
    backgroundColor: '#F7F7F7',
    width: '100%'

  },
  button: {
    alignSelf: 'stretch',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'blue',
    paddingHorizontal: 10,
    minHeight: 40,
  },
  buttonText: {
    fontSize: 20,
    color: 'white',
  },
  form: {
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },

});