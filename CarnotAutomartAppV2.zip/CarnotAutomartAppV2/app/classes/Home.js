import React, { Component } from 'react';
import { ScrollView, StyleSheet, Dimensions, header, Image, Button, View, Text, TouchableHighlight } from 'react-native';

export default class Home extends Component {
	static navigationOptions = { title: 'Welcome', header: null };
	
	render() {
		return (
			<ScrollView style={styles.scrollContainer}>

				<View style={styles.gridView}>
					<View style={styles.logo}>
						<Image  source={require('./../images/logo.png')} />		
						<Text style={styles.logoText}> Welcome to Carnoautomart </Text>				
					</View>
					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId:1
						})} >
						<View style={styles.box}>
							<Image style={styles.boxImage} source={require('./../images/images1.png')} />
							<Text style={styles.boxText}>New & Used Car</Text>
						</View>
					</TouchableHighlight>

					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId: 5
							
						})} >
						<View style={styles.box}>
							<Image style={styles.boxImage} source={require('./../images/images2.png')} />
							<Text style={styles.boxText}>Import Car</Text>
						</View>
					</TouchableHighlight>

					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId: 3
							
						})} >
						<View style={styles.box}>
							<Image style={styles.boxImage} source={require('./../images/images3.png')} />
							<Text style={styles.boxText}>Buy Motorbike</Text>
						</View>
					</TouchableHighlight>
					
					<View style={styles.box}>
						<Image style={styles.boxImage} source={require('./../images/images4.png')} />
						<Text style={styles.boxText}>Sell My Car</Text>
					</View>
				
					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId: 2
							
						})} >
						<View style={styles.box}>
							<Image style={styles.boxImage} source={require('./../images/images5.png')} />
							<Text style={styles.boxText}>Vans</Text>
						</View>
					</TouchableHighlight>

					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId: 4
						
						})} >
						<View style={styles.box}>
							<Image style={styles.boxImage} source={require('./../images/images6.png')} />
							<Text style={styles.boxText}>Spare Parts</Text>
						</View>
					</TouchableHighlight>

					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Search', {
							itemId: 99
							
						})} >
						<View style={styles.boxCenter}>
							<Image style={styles.boxImage} source={require('./../images/images7.png')} />
							<Text style={styles.boxText}>Auto Mech</Text>
						</View>
					</TouchableHighlight>

					<TouchableHighlight
						onPress={() => this.props.navigation.navigate('Filterform', {
							itemId: 88
							
						})} >
						<View style={styles.boxCenter}>
							
							<Text style={styles.boxText}>Search Form</Text>
						</View>
					</TouchableHighlight>

				</View>

				<View style={styles.footer}>
					<Text style={styles.boxTextfooter}>
						<Image style={styles.footerImage} source={require('./../images/location.png')} />
						&nbsp;94A Allen Avenue, Ikeja, Lagos State Nigeria
					</Text>
					<Text style={styles.boxTextfooter}>
						<Image style={styles.footerImage} source={require('./../images/phone.png')} />
						&nbsp;+234 (0) 9055566881 </Text>
					<Text style={styles.boxTextfooter}>
						<Image style={styles.footerImage} source={require('./../images/message.png')} />
						&nbsp;info@carnotautomart.com</Text>
				</View>
			</ScrollView >
		);
	}
}


const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	logo:{ 
		   alignItems: 'center', 
	       width: Dimensions.get('window').width/1.11,
		   paddingTop: 20, 
		   paddingBottom: 20,
		
		   backgroundColor:'#F7F7F7' 
		},
	logoText:{
		      alignItems:'center',
			  fontSize:20,
			  color:'green',
			  
			},
	scrollContainer: {
		flex: 1,
		margin: 0,
		paddingBottom: 0,
		position: 'relative',
		backgroundColor:'#F7F7F7',
		width:'100%'
	
	},
	gridView: {
		flexDirection: 'row',
		flexWrap: 'wrap',
		paddingLeft: 10
	},
	box: {
		height: 100,
		width: Dimensions.get('window').width/3.1,
		paddingBottom: 25,
		paddingTop: 10,
		alignItems: 'center',
		
	},
	boxCenter: {
		height: 100,
		width: Dimensions.get('window').width,
		paddingBottom: 120,
		alignItems: 'center'
	},
	boxImage: {
		width: 50,
		height: 50,

	},
	boxText: {
		fontWeight: '500',
		fontSize: 14,
		textAlign: 'center'
	},
	footer: {
		backgroundColor: '#012A46',
		marginTop: '18%',
		paddingTop: 10,
		paddingBottom: '15%'
	},
	boxTextfooter: {
		color: 'white',
		textAlign: 'center'
	},
	footerImage: {
		alignItems: 'center',
		height: 25,
		width: 25
	}

});